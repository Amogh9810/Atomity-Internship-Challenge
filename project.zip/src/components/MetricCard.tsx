import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

interface MetricCardProps {
  label: string;
  value: number;
  unit: string;
  color: string;
  isVisible: boolean;
  index: number;
}

export function MetricCard({
  label,
  value,
  unit,
  color,
  isVisible,
  index,
}: MetricCardProps) {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    if (!isVisible) {
      setDisplayValue(0);
      return;
    }

    const startTime = Date.now();
    const duration = 2000; // 2 second count-up

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Easing function for smooth count-up
      const easeOutQuad = 1 - (1 - progress) * (1 - progress);
      const current = Math.floor(value * easeOutQuad);

      setDisplayValue(current);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [isVisible, value]);

  return (
    <motion.div
      className="relative overflow-hidden rounded-lg border border-cyan-500/30 bg-slate-900/50 p-6 backdrop-blur-sm"
      initial={{ opacity: 0, y: 20 }}
      animate={
        isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }
      }
      transition={{
        type: 'spring',
        stiffness: 100,
        damping: 15,
        delay: 0.6 + index * 0.15,
      }}
      whileHover={{ scale: 1.05, borderColor: '#00D9FF' }}
    >
      {/* Gradient background accent */}
      <div
        className={`absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity pointer-events-none bg-gradient-to-br ${color}`}
      />

      {/* Top accent bar */}
      <motion.div
        className={`absolute top-0 left-0 h-1 bg-gradient-to-r ${color}`}
        initial={{ width: 0 }}
        animate={isVisible ? { width: '100%' } : { width: 0 }}
        transition={{ duration: 0.8, delay: 0.6 + index * 0.15 }}
      />

      {/* Content */}
      <div className="relative z-10">
        {/* Label */}
        <p className="text-sm font-medium text-cyan-300 mb-2 uppercase tracking-wider">
          {label}
        </p>

        {/* Value */}
        <motion.div className="mb-3">
          <motion.span
            className={`text-5xl font-bold bg-gradient-to-r ${color} bg-clip-text text-transparent`}
          >
            {displayValue}
          </motion.span>
          <span className="text-xl font-semibold text-cyan-300 ml-1">
            {unit}
          </span>
        </motion.div>

        {/* Progress bar */}
        <div className="relative h-2 bg-slate-800/50 rounded-full overflow-hidden">
          <motion.div
            className={`h-full rounded-full bg-gradient-to-r ${color}`}
            initial={{ width: 0 }}
            animate={isVisible ? { width: `${displayValue}%` } : { width: 0 }}
            transition={{ duration: 2, ease: 'easeOut' }}
          />
        </div>
      </div>
    </motion.div>
  );
}
