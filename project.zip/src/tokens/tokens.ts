// Design tokens for Arc Reactor theme
export const tokens = {
  colors: {
    // Primary energy colors
    primary: '#00D9FF', // Cyan glow
    primaryDark: '#00A3CC',
    secondary: '#0066FF', // Electric blue
    
    // Arc Reactor specific
    reactorCore: '#FFD700', // Gold center
    reactorGlow: '#FF6B35', // Orange glow
    energyPulse: '#00D9FF',
    
    // Neutral palette
    background: '#0A0E27', // Dark navy
    surface: '#141B2F',
    surfaceLight: '#1F2A47',
    
    // Text
    textPrimary: '#E8ECFF',
    textSecondary: '#A0AACE',
    textMuted: '#7A8399',
    
    // Functional
    success: '#00FF88',
    warning: '#FFB800',
    error: '#FF3B3B',
  },
  
  spacing: {
    xs: '0.25rem',
    sm: '0.5rem',
    md: '1rem',
    lg: '1.5rem',
    xl: '2rem',
    '2xl': '3rem',
    '3xl': '4rem',
  },
  
  radii: {
    none: '0',
    sm: '0.25rem',
    md: '0.5rem',
    lg: '1rem',
    xl: '1.5rem',
    full: '9999px',
  },
  
  shadows: {
    sm: '0 1px 2px rgba(0, 0, 0, 0.5)',
    md: '0 4px 12px rgba(0, 0, 0, 0.5)',
    lg: '0 12px 32px rgba(0, 0, 0, 0.6)',
    glow: '0 0 20px rgba(0, 217, 255, 0.3)',
    glowIntense: '0 0 40px rgba(0, 217, 255, 0.6)',
    reactorGlow: '0 0 60px rgba(255, 107, 53, 0.4)',
  },
  
  animation: {
    fast: '200ms',
    base: '300ms',
    slow: '500ms',
    verySlow: '800ms',
    
    // Spring physics
    spring: {
      smooth: { type: 'spring', stiffness: 100, damping: 10 },
      snappy: { type: 'spring', stiffness: 150, damping: 12 },
      bouncy: { type: 'spring', stiffness: 80, damping: 8 },
    },
  },
  
  typography: {
    // Heading styles
    h1: {
      size: 'clamp(1.5rem, 5vw, 3rem)',
      weight: 700,
      lineHeight: 1.2,
    },
    h2: {
      size: 'clamp(1.25rem, 4vw, 2rem)',
      weight: 700,
      lineHeight: 1.3,
    },
    h3: {
      size: 'clamp(1rem, 3vw, 1.5rem)',
      weight: 600,
      lineHeight: 1.4,
    },
    // Body text
    body: {
      size: '1rem',
      weight: 400,
      lineHeight: 1.6,
    },
    bodySmall: {
      size: '0.875rem',
      weight: 400,
      lineHeight: 1.5,
    },
  },
} as const;

// CSS variable definitions for use in stylesheets
export const tokensCss = `
  :root {
    --color-primary: ${tokens.colors.primary};
    --color-primary-dark: ${tokens.colors.primaryDark};
    --color-secondary: ${tokens.colors.secondary};
    --color-reactor-core: ${tokens.colors.reactorCore};
    --color-reactor-glow: ${tokens.colors.reactorGlow};
    --color-energy-pulse: ${tokens.colors.energyPulse};
    --color-background: ${tokens.colors.background};
    --color-surface: ${tokens.colors.surface};
    --color-surface-light: ${tokens.colors.surfaceLight};
    --color-text-primary: ${tokens.colors.textPrimary};
    --color-text-secondary: ${tokens.colors.textSecondary};
    --color-text-muted: ${tokens.colors.textMuted};
    --color-success: ${tokens.colors.success};
    --color-warning: ${tokens.colors.warning};
    --color-error: ${tokens.colors.error};
    
    --spacing-xs: ${tokens.spacing.xs};
    --spacing-sm: ${tokens.spacing.sm};
    --spacing-md: ${tokens.spacing.md};
    --spacing-lg: ${tokens.spacing.lg};
    --spacing-xl: ${tokens.spacing.xl};
    --spacing-2xl: ${tokens.spacing['2xl']};
    --spacing-3xl: ${tokens.spacing['3xl']};
    
    --radius-sm: ${tokens.radii.sm};
    --radius-md: ${tokens.radii.md};
    --radius-lg: ${tokens.radii.lg};
    --radius-xl: ${tokens.radii.xl};
    --radius-full: ${tokens.radii.full};
    
    --shadow-sm: ${tokens.shadows.sm};
    --shadow-md: ${tokens.shadows.md};
    --shadow-lg: ${tokens.shadows.lg};
    --shadow-glow: ${tokens.shadows.glow};
    --shadow-glow-intense: ${tokens.shadows.glowIntense};
    --shadow-reactor-glow: ${tokens.shadows.reactorGlow};
  }
`;
