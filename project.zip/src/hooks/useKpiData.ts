import { useQuery } from '@tanstack/react-query';

export interface KpiMetric {
  label: string;
  value: number;
  unit: string;
  color: string;
}

const providerMetricsMap: Record<string, KpiMetric[]> = {
  default: [
    {
      label: 'System Uptime',
      value: 99.99,
      unit: '%',
      color: 'from-green-500 to-emerald-600',
    },
    {
      label: 'Avg Latency',
      value: 12,
      unit: 'ms',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      label: 'Throughput',
      value: 95000,
      unit: 'req/s',
      color: 'from-purple-500 to-pink-600',
    },
    {
      label: 'Energy Efficiency',
      value: 98,
      unit: '%',
      color: 'from-orange-500 to-red-600',
    },
  ],
  AWS: [
    {
      label: 'System Uptime',
      value: 99.99,
      unit: '%',
      color: 'from-yellow-500 to-orange-600',
    },
    {
      label: 'Avg Latency',
      value: 8,
      unit: 'ms',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      label: 'Throughput',
      value: 120000,
      unit: 'req/s',
      color: 'from-purple-500 to-pink-600',
    },
    {
      label: 'Energy Efficiency',
      value: 96,
      unit: '%',
      color: 'from-orange-500 to-red-600',
    },
  ],
  Azure: [
    {
      label: 'System Uptime',
      value: 99.95,
      unit: '%',
      color: 'from-blue-500 to-cyan-600',
    },
    {
      label: 'Avg Latency',
      value: 10,
      unit: 'ms',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      label: 'Throughput',
      value: 110000,
      unit: 'req/s',
      color: 'from-purple-500 to-pink-600',
    },
    {
      label: 'Energy Efficiency',
      value: 94,
      unit: '%',
      color: 'from-orange-500 to-red-600',
    },
  ],
  GCP: [
    {
      label: 'System Uptime',
      value: 99.97,
      unit: '%',
      color: 'from-red-500 to-orange-600',
    },
    {
      label: 'Avg Latency',
      value: 9,
      unit: 'ms',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      label: 'Throughput',
      value: 115000,
      unit: 'req/s',
      color: 'from-purple-500 to-pink-600',
    },
    {
      label: 'Energy Efficiency',
      value: 95,
      unit: '%',
      color: 'from-orange-500 to-red-600',
    },
  ],
  'On-Prem': [
    {
      label: 'System Uptime',
      value: 99.89,
      unit: '%',
      color: 'from-green-500 to-emerald-600',
    },
    {
      label: 'Avg Latency',
      value: 15,
      unit: 'ms',
      color: 'from-cyan-500 to-blue-600',
    },
    {
      label: 'Throughput',
      value: 85000,
      unit: 'req/s',
      color: 'from-purple-500 to-pink-600',
    },
    {
      label: 'Energy Efficiency',
      value: 92,
      unit: '%',
      color: 'from-orange-500 to-red-600',
    },
  ],
};

async function fetchKpiData(providerId?: string): Promise<KpiMetric[]> {
  await new Promise((resolve) => setTimeout(resolve, 300));
  return providerMetricsMap[providerId || 'default'] || providerMetricsMap.default;
}

export function useKpiData(providerId?: string) {
  return useQuery({
    queryKey: ['kpi-metrics', providerId],
    queryFn: () => fetchKpiData(providerId),
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes (formerly cacheTime)
    retry: 2,
  });
}
