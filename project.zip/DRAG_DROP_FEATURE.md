# Arc Reactor Drag-and-Drop Feature

## Overview

The Arc Reactor Cloud Intelligence Engine now features an interactive drag-and-drop system that allows users to select cloud provider reactors and view their detailed metrics in real-time.

## Layout Architecture

### Left Column (Reactors)
- **Central Arc Reactor**: Large central visualization with animated rings, orbiting particles, and pulsing core
- **Small Reactors Grid**: Four draggable cloud provider reactors (2x2 grid)
  - **AWS**: Orange-themed reactor
  - **Azure**: Cyan-themed reactor
  - **GCP**: Red-themed reactor
  - **On-Prem**: Green-themed reactor

### Right Column (Metrics)
- **Dynamic Metrics Display**: Shows 4 KPI cards that update based on the selected reactor
- **Default View**: System-wide aggregated metrics
- **Provider-Specific View**: Detailed metrics when a reactor is dropped into the center

## Features

### Drag-and-Drop System
- **Draggable Items**: Each small reactor is fully draggable with visual feedback
- **Drop Zone**: The central Arc Reactor acts as the drop target
- **Visual Feedback**:
  - Hovering on a small reactor: scales up 1.1x and increases glow
  - During drag: reactor becomes semi-transparent (0.5 opacity)
  - Over drop zone: pulsing cyan dashed border appears, outer glow intensifies
  
### Metrics Updates
When a reactor is dropped into the central reactor:

**AWS Metrics**:
- System Uptime: 99.99%
- Avg Latency: 8ms
- Throughput: 120,000 req/s
- Energy Efficiency: 96%

**Azure Metrics**:
- System Uptime: 99.95%
- Avg Latency: 10ms
- Throughput: 110,000 req/s
- Energy Efficiency: 94%

**GCP Metrics**:
- System Uptime: 99.97%
- Avg Latency: 9ms
- Throughput: 115,000 req/s
- Energy Efficiency: 95%

**On-Prem Metrics**:
- System Uptime: 99.89%
- Avg Latency: 15ms
- Throughput: 85,000 req/s
- Energy Efficiency: 92%

### Animations
- **Small Reactors**: Rotating rings at different speeds with color-coded glow
- **Central Reactor**: Three concentric rotating rings with pulsing golden core and orbiting particles
- **Metrics Cards**: Smooth count-up animation with easing and color-coded progress bars
- **Transitions**: Smooth fade and slide transitions when switching between providers

## Component Structure

```
FeatureSection
├── ArcReactor (Central drop target)
│   └── Drop detection and visual feedback
├── SmallReactor (x4)
│   └── Drag initiation and provider identification
└── MetricCard (x4)
    └── Provider-specific KPI display
```

## State Management

- **selectedReactorId**: Tracks which reactor is currently selected (null = default view)
- **isDragOver**: Indicates when a reactor is being dragged over the drop zone
- **draggedReactorId**: Tracks which reactor is currently being dragged
- **powerLevel**: Controls visual intensity of the central reactor
- **isVisible**: Triggers entrance animations on scroll

## Data Flow

```
User Drags Reactor
    ↓
handleDragStart() → sets draggedReactorId and dataTransfer
    ↓
handleDragOver() → sets isDragOver = true, shows visual feedback
    ↓
handleDrop() → calls onDrop() with reactorId
    ↓
setSelectedReactorId(reactorId)
    ↓
useKpiData(providerName) → fetches provider-specific metrics
    ↓
MetricCards re-render with new values
    ↓
Smooth AnimatePresence transition to new metrics
```

## Browser Compatibility

- Modern drag-and-drop API (HTML5 standard)
- Tested on Chrome, Firefox, Safari, and Edge
- Mobile-responsive with grid layout adjustments
- Fallback text guides users to drag action

## Files Modified

- `src/components/SmallReactor.tsx` - NEW: Draggable reactor component
- `src/components/ArcReactor.tsx` - Updated with drop zone support
- `src/components/FeatureSection.tsx` - Refactored to 2-column layout
- `src/hooks/useKpiData.ts` - Added provider-specific metrics
- `src/components/MetricCard.tsx` - No changes (works with new data structure)

## Usage

1. **View Default Metrics**: Page loads with system-wide aggregated metrics
2. **Hover on Reactor**: Small reactor scales up and glows more intensely
3. **Drag Reactor**: Click and drag any small reactor toward the center
4. **Over Central Reactor**: Center shows pulsing cyan border, indicating drop zone
5. **Release to Drop**: Release mouse to select reactor and view its metrics
6. **View Updated Metrics**: Right panel updates with provider-specific KPIs
7. **Reactor Active Indicator**: Text below small reactors shows which one is active
